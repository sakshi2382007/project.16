
var box1;

function setup() {
  createCanvas(600, 400);
  
}

function draw() {
  background(220);

}

